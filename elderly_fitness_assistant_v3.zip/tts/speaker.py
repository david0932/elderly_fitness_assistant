import pyttsx3

class Speaker:
    def __init__(self, rate=160, volume=1.0):
        self.engine = pyttsx3.init()
        self.engine.setProperty('rate', rate)
        self.engine.setProperty('volume', volume)
        self.last_warn_time = 0
        self.last_good_time = 0

    def say(self, text):
        self.engine.say(text)
        self.engine.runAndWait()
